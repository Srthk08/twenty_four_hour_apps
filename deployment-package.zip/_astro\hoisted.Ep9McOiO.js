import"./ProductDialog.astro_astro_type_script_index_0_lang.DRfKF35q.js";import"https://unpkg.com/@supabase/supabase-js@2";
